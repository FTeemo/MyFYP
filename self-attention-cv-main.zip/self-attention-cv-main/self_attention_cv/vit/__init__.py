from .R50_ViT import ResNet50ViT
from .vit import ViT
